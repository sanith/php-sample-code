strip_html_tags.php
  David R. Nadeau
  NadeauSoftware.com

These files are distributed under a BSD license that enables you to use,
modify and redistribute this code as you see fit.  Please note the
copyright statement in the source code.

Please see the accompanying article:

http://nadeausoftware.com/articles/2007/09/php_tip_how_strip_html_tags_web_page
